function setup() {
  createCanvas(400, 400);
}

function draw() {
  background(120, 151, 230);

// The ground
fill(15, 176, 7);
rect(0, 300, 400, 100);

// The sun
fill(241, 252, 91);
ellipse(80, 64, 100, 100); 

// The snowman
fill(235, 217, 217);
ellipse(200, 300, 150, 150);
ellipse(200, 200, 100, 100);
ellipse(200, 120, 75, 75);
  
//nose
fill(255,128,0)
triangle(200, 125, 250, 130, 200, 140);
  
//eyes & coals & hat
fill(0,0,0)
ellipse(185,110, 10, 10);
ellipse(215, 110, 10, 10);
ellipse(200, 230, 8, 9);
ellipse(205, 210, 7, 8);
ellipse(197, 190, 8, 7);
rect(177, 35, 45, 55);
line(165,90, 230, 90)
}